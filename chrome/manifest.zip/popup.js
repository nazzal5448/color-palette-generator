/**
 * Color Palette Generator - Browser Extension Logic
 * Offline-first, premium color harmony calculations.
 */

// --- STATE MANAGEMENT ---
let state = {
  baseColor: '#6366F1', // Hex string format (with #)
  harmonyType: 'complementary', // complementary, analogous, triadic, monochromatic
  activeTab: 'generate', // generate, saved, history, info
  currentPalette: [], // Array of 5 hex strings
  theme: 'dark' // light, dark
};

// History limit
const MAX_HISTORY = 20;

// Debounce timer for history addition
let historyDebounceTimer = null;

// --- DOM ELEMENTS ---
const elements = {
  themeToggle: document.getElementById('theme-toggle'),
  tabBtns: document.querySelectorAll('.tab-btn'),
  tabContents: document.querySelectorAll('.tab-content'),
  
  // Generate Tab Inputs
  baseColorPicker: document.getElementById('base-color-picker'),
  colorWheelPreview: document.getElementById('color-wheel-preview'),
  hexTextInput: document.getElementById('hex-text-input'),
  sliderR: document.getElementById('slider-r'),
  sliderG: document.getElementById('slider-g'),
  sliderB: document.getElementById('slider-b'),
  valR: document.getElementById('val-r'),
  valG: document.getElementById('val-g'),
  valB: document.getElementById('val-b'),
  harmonyPills: document.querySelectorAll('.harmony-pill'),
  harmonyPaletteDisplay: document.getElementById('harmony-palette-display'),
  savePaletteBtn: document.getElementById('save-palette-btn'),
  
  // Saved Tab
  savedSearchInput: document.getElementById('saved-search-input'),
  savedListContainer: document.getElementById('saved-list-container'),
  
  // History Tab
  clearHistoryBtn: document.getElementById('clear-history-btn'),
  historyListContainer: document.getElementById('history-list-container'),
  
  // Save Name Modal
  saveModal: document.getElementById('save-modal'),
  paletteNameInput: document.getElementById('palette-name-input'),
  modalCancelBtn: document.getElementById('modal-cancel-btn'),
  modalConfirmBtn: document.getElementById('modal-confirm-btn'),
  
  // Toast
  toastNotification: document.getElementById('toast-notification'),
  toastMessage: document.getElementById('toast-message')
};

// --- COLOR MATHEMATICS ---

/**
 * Parses Hex to [R, G, B]
 */
function hexToRgb(hex) {
  let cleanHex = hex.trim().replace('#', '');
  if (cleanHex.length === 3) {
    cleanHex = cleanHex.split('').map(c => c + c).join('');
  }
  const val = parseInt(cleanHex, 16);
  const r = (val >> 16) & 0xFF;
  const g = (val >> 8) & 0xFF;
  const b = val & 0xFF;
  return [r, g, b];
}

/**
 * Converts RGB to HEX
 */
function rgbToHex(r, g, b) {
  const rStr = r.toString(16).padStart(2, '0').toUpperCase();
  const gStr = g.toString(16).padStart(2, '0').toUpperCase();
  const bStr = b.toString(16).padStart(2, '0').toUpperCase();
  return `#${rStr}${gStr}${bStr}`;
}

/**
 * Converts RGB to HSL
 */
function rgbToHsl(r, g, b) {
  const rNorm = r / 255;
  const gNorm = g / 255;
  const bNorm = b / 255;

  const max = Math.max(rNorm, gNorm, bNorm);
  const min = Math.min(rNorm, gNorm, bNorm);
  const delta = max - min;

  let h = 0;
  let s = 0;
  const l = (max + min) / 2;

  if (delta !== 0) {
    if (l < 0.5) {
      s = delta / (max + min);
    } else {
      s = delta / (2.0 - max - min);
    }

    if (max === rNorm) {
      h = (gNorm - bNorm) / delta + (gNorm < bNorm ? 6 : 0);
    } else if (max === gNorm) {
      h = (bNorm - rNorm) / delta + 2;
    } else if (max === bNorm) {
      h = (rNorm - gNorm) / delta + 4;
    }

    h *= 60;
  }

  return { hue: h, saturation: s, lightness: l };
}

/**
 * Helper for HSL to RGB
 */
function hueToRgb(p, q, t) {
  if (t < 0) t += 1;
  if (t > 1) t -= 1;
  if (t < 1/6) return p + (q - p) * 6 * t;
  if (t < 1/2) return q;
  if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
  return p;
}

/**
 * Converts HSL properties to [R, G, B]
 */
function hslToRgb(h, s, l) {
  const hueNorm = h / 360;
  let r, g, b;

  if (s === 0) {
    r = g = b = l; // achromatic
  } else {
    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
    const p = 2 * l - q;

    r = hueToRgb(p, q, hueNorm + 1/3);
    g = hueToRgb(p, q, hueNorm);
    b = hueToRgb(p, q, hueNorm - 1/3);
  }

  return [
    Math.min(255, Math.max(0, Math.round(r * 255))),
    Math.min(255, Math.max(0, Math.round(g * 255))),
    Math.min(255, Math.max(0, Math.round(b * 255)))
  ];
}

/**
 * Converts HSL to Hex
 */
function hslToHex(h, s, l) {
  const [r, g, b] = hslToRgb(h, s, l);
  return rgbToHex(r, g, b);
}

/**
 * Deterministic Complementary palette generator
 */
function generateComplementary(baseHex) {
  const [r, g, b] = hexToRgb(baseHex);
  const hsl = rgbToHsl(r, g, b);
  const compHue = (hsl.hue + 180) % 360;

  return [
    hslToHex(hsl.hue, hsl.saturation, Math.min(0.9, hsl.lightness + 0.15)),
    baseHex,
    hslToHex(hsl.hue, hsl.saturation, Math.max(0.1, hsl.lightness - 0.15)),
    hslToHex(compHue, hsl.saturation, hsl.lightness),
    hslToHex(compHue, hsl.saturation, Math.max(0.1, hsl.lightness - 0.2))
  ];
}

/**
 * Deterministic Analogous palette generator
 */
function generateAnalogous(baseHex) {
  const [r, g, b] = hexToRgb(baseHex);
  const hsl = rgbToHsl(r, g, b);
  const left2 = (hsl.hue - 30 + 360) % 360;
  const left1 = (hsl.hue - 15 + 360) % 360;
  const right1 = (hsl.hue + 15) % 360;
  const right2 = (hsl.hue + 30) % 360;

  return [
    hslToHex(left2, hsl.saturation, hsl.lightness),
    hslToHex(left1, hsl.saturation, hsl.lightness),
    baseHex,
    hslToHex(right1, hsl.saturation, hsl.lightness),
    hslToHex(right2, hsl.saturation, hsl.lightness)
  ];
}

/**
 * Deterministic Triadic palette generator
 */
function generateTriadic(baseHex) {
  const [r, g, b] = hexToRgb(baseHex);
  const hsl = rgbToHsl(r, g, b);
  const hue2 = (hsl.hue + 120) % 360;
  const hue3 = (hsl.hue + 240) % 360;

  return [
    hslToHex(hsl.hue, hsl.saturation, Math.min(0.85, hsl.lightness + 0.15)),
    baseHex,
    hslToHex(hue2, hsl.saturation, hsl.lightness),
    hslToHex(hue3, hsl.saturation, hsl.lightness),
    hslToHex(hue3, hsl.saturation, Math.max(0.15, hsl.lightness - 0.2))
  ];
}

/**
 * Deterministic Monochromatic palette generator
 */
function generateMonochromatic(baseHex) {
  const [r, g, b] = hexToRgb(baseHex);
  const hsl = rgbToHsl(r, g, b);

  return [
    hslToHex(hsl.hue, hsl.saturation, 0.90),
    hslToHex(hsl.hue, hsl.saturation, 0.70),
    baseHex,
    hslToHex(hsl.hue, hsl.saturation, 0.40),
    hslToHex(hsl.hue, hsl.saturation, 0.15)
  ];
}

/**
 * Returns current palette based on state
 */
function generatePalette(baseHex, type) {
  switch (type) {
    case 'analogous': return generateAnalogous(baseHex);
    case 'triadic': return generateTriadic(baseHex);
    case 'monochromatic': return generateMonochromatic(baseHex);
    case 'complementary':
    default:
      return generateComplementary(baseHex);
  }
}

// --- PERSISTENCE ---

function getSavedPalettes() {
  const raw = localStorage.getItem('saved_palettes');
  return raw ? JSON.parse(raw) : [];
}

function savePalette(name, harmonyType, colors) {
  const saved = getSavedPalettes();
  const newPalette = {
    id: Date.now().toString(),
    name: name.trim() || 'Untitled Harmony',
    harmonyType,
    colors,
    createdAt: new Date().toISOString()
  };
  saved.unshift(newPalette);
  localStorage.setItem('saved_palettes', JSON.stringify(saved));
  renderSavedPalettes();
}

function deleteSavedPalette(id) {
  let saved = getSavedPalettes();
  saved = saved.filter(p => p.id !== id);
  localStorage.setItem('saved_palettes', JSON.stringify(saved));
  renderSavedPalettes();
}

function getHistory() {
  const raw = localStorage.getItem('palette_history');
  return raw ? JSON.parse(raw) : [];
}

function addToHistory(baseHex, harmonyType, colors) {
  let history = getHistory();
  
  // Check if identical colors palette already exists as the first element to avoid spam
  if (history.length > 0 && JSON.stringify(history[0].colors) === JSON.stringify(colors)) {
    return;
  }

  const newHistoryItem = {
    id: Date.now().toString(),
    baseHex,
    harmonyType,
    colors,
    createdAt: new Date().toISOString()
  };

  history.unshift(newHistoryItem);
  if (history.length > MAX_HISTORY) {
    history = history.slice(0, MAX_HISTORY);
  }
  
  localStorage.setItem('palette_history', JSON.stringify(history));
  renderHistory();
}

function deleteHistoryItem(id) {
  let history = getHistory();
  history = history.filter(p => p.id !== id);
  localStorage.setItem('palette_history', JSON.stringify(history));
  renderHistory();
}

function clearHistory() {
  localStorage.setItem('palette_history', JSON.stringify([]));
  renderHistory();
}

// --- USER INTERFACE RENDERING ---

/**
 * Custom slider track gradient updates
 */
function updateSliderTrackColors(r, g, b) {
  elements.sliderR.style.background = `linear-gradient(to right, ${rgbToHex(0, g, b)}, ${rgbToHex(255, g, b)})`;
  elements.sliderG.style.background = `linear-gradient(to right, ${rgbToHex(r, 0, b)}, ${rgbToHex(r, 255, b)})`;
  elements.sliderB.style.background = `linear-gradient(to right, ${rgbToHex(r, g, 0)}, ${rgbToHex(r, g, 255)})`;
}

/**
 * Triggers feedback toast
 */
function showToast(message) {
  elements.toastMessage.textContent = message;
  elements.toastNotification.classList.remove('hidden');
  
  // Clear any existing transitions
  elements.toastNotification.style.transition = 'none';
  elements.toastNotification.offsetHeight; // trigger reflow
  elements.toastNotification.style.transition = '';
  
  setTimeout(() => {
    elements.toastNotification.classList.add('hidden');
  }, 1800);
}

/**
 * Helper to write color values into clipboard
 */
function copyToClipboard(text, successMsg) {
  navigator.clipboard.writeText(text).then(() => {
    showToast(successMsg);
  }).catch(() => {
    showToast('Failed to copy');
  });
}

/**
 * Render main generator palette strips
 */
function renderActivePalette() {
  elements.harmonyPaletteDisplay.innerHTML = '';
  
  state.currentPalette.forEach((hexColor) => {
    const [r, g, b] = hexToRgb(hexColor);
    const rgbText = `rgb(${r}, ${g}, ${b})`;
    
    const bar = document.createElement('div');
    bar.className = 'color-bar';
    bar.style.backgroundColor = hexColor;
    
    // Copy indicators SVG overlay
    const copyInd = document.createElement('div');
    copyInd.className = 'color-bar-copy-indicator';
    copyInd.innerHTML = `
      <svg viewBox="0 0 24 24" width="14" height="14" stroke-width="2.5">
        <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
        <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path>
      </svg>
    `;
    bar.appendChild(copyInd);

    const hexLabel = document.createElement('span');
    hexLabel.className = 'color-bar-hex';
    hexLabel.textContent = hexColor;
    bar.appendChild(hexLabel);

    const rgbLabel = document.createElement('span');
    rgbLabel.className = 'color-bar-rgb';
    rgbLabel.textContent = rgbText;
    bar.appendChild(rgbLabel);
    
    // Click behavior (copy HEX)
    bar.addEventListener('click', () => {
      copyToClipboard(hexColor, `Copied HEX: ${hexColor}`);
    });
    
    // Double click behavior (copy RGB)
    bar.addEventListener('dblclick', (e) => {
      e.stopPropagation();
      copyToClipboard(rgbText, `Copied RGB: ${rgbText}`);
    });

    elements.harmonyPaletteDisplay.appendChild(bar);
  });
}

/**
 * Build mini preview strip of 5 blocks
 */
function createMiniColorStripHTML(colors) {
  let html = `<div class="palette-card-colors">`;
  colors.forEach(col => {
    html += `<div class="palette-card-color-block" style="background-color: ${col}" title="${col}"></div>`;
  });
  html += `</div>`;
  return html;
}

/**
 * Render Saved Tab list
 */
function renderSavedPalettes() {
  const saved = getSavedPalettes();
  const query = elements.savedSearchInput.value.toLowerCase().trim();
  
  elements.savedListContainer.innerHTML = '';
  
  const filtered = saved.filter(p => {
    const nameMatch = p.name.toLowerCase().includes(query);
    const typeMatch = p.harmonyType.toLowerCase().includes(query);
    const colorMatch = p.colors.some(c => c.toLowerCase().includes(query));
    return nameMatch || typeMatch || colorMatch;
  });

  if (filtered.length === 0) {
    elements.savedListContainer.innerHTML = `
      <div class="empty-state">
        <svg viewBox="0 0 24 24" width="36" height="36" stroke="currentColor" stroke-width="2">
          <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
        </svg>
        <p>${query ? 'No matching saved palettes.' : 'No saved palettes yet. Start saving in the Generate tab!'}</p>
      </div>
    `;
    return;
  }

  filtered.forEach(p => {
    const card = document.createElement('div');
    card.className = 'palette-card glass';
    
    card.innerHTML = `
      <div class="palette-card-header">
        <span class="palette-card-title">${p.name}</span>
        <span class="palette-card-meta">${p.harmonyType}</span>
      </div>
      ${createMiniColorStripHTML(p.colors)}
      <div class="palette-card-actions">
        <button class="card-action-btn load-btn" data-base="${p.colors[2] || p.colors[0]}" data-harmony="${p.harmonyType}">
          <svg viewBox="0 0 24 24" width="10" height="10"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"></path></svg>
          Load
        </button>
        <button class="card-action-btn copy-all-btn">
          <svg viewBox="0 0 24 24" width="10" height="10"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
          Copy All
        </button>
        <button class="card-action-btn delete-btn">
          <svg viewBox="0 0 24 24" width="10" height="10"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          Delete
        </button>
      </div>
    `;

    // Hook card button click events
    card.querySelector('.load-btn').addEventListener('click', () => {
      loadPaletteIntoGenerator(p.colors[2] || p.colors[0], p.harmonyType);
    });

    card.querySelector('.copy-all-btn').addEventListener('click', () => {
      copyToClipboard(p.colors.join(', '), 'Copied all HEX colors!');
    });

    card.querySelector('.delete-btn').addEventListener('click', () => {
      deleteSavedPalette(p.id);
    });

    // Color blocks copy triggers
    const colorBlocks = card.querySelectorAll('.palette-card-color-block');
    colorBlocks.forEach((block, index) => {
      block.addEventListener('click', () => {
        const c = p.colors[index];
        copyToClipboard(c, `Copied HEX: ${c}`);
      });
    });

    elements.savedListContainer.appendChild(card);
  });
}

/**
 * Render History Tab list
 */
function renderHistory() {
  const history = getHistory();
  elements.historyListContainer.innerHTML = '';

  if (history.length === 0) {
    elements.historyListContainer.innerHTML = `
      <div class="empty-state">
        <svg viewBox="0 0 24 24" width="36" height="36" stroke="currentColor" stroke-width="2">
          <circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline>
        </svg>
        <p>No palette history yet. Generated colors will show up here.</p>
      </div>
    `;
    return;
  }

  history.forEach(p => {
    const card = document.createElement('div');
    card.className = 'palette-card glass';
    
    card.innerHTML = `
      <div class="palette-card-header">
        <span class="palette-card-title">${p.colors[2]} (${p.harmonyType})</span>
        <span class="palette-card-meta">${p.harmonyType}</span>
      </div>
      ${createMiniColorStripHTML(p.colors)}
      <div class="palette-card-actions">
        <button class="card-action-btn load-btn" data-base="${p.baseHex}" data-harmony="${p.harmonyType}">
          <svg viewBox="0 0 24 24" width="10" height="10"><path d="M21.5 2v6h-6M21.34 15.57a10 10 0 1 1-.57-8.38l5.67-5.67"></path></svg>
          Load
        </button>
        <button class="card-action-btn copy-all-btn">
          <svg viewBox="0 0 24 24" width="10" height="10"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg>
          Copy All
        </button>
        <button class="card-action-btn delete-btn">
          <svg viewBox="0 0 24 24" width="10" height="10"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>
          Delete
        </button>
      </div>
    `;

    // Hook card action events
    card.querySelector('.load-btn').addEventListener('click', () => {
      loadPaletteIntoGenerator(p.baseHex, p.harmonyType);
    });

    card.querySelector('.copy-all-btn').addEventListener('click', () => {
      copyToClipboard(p.colors.join(', '), 'Copied all HEX colors!');
    });

    card.querySelector('.delete-btn').addEventListener('click', () => {
      deleteHistoryItem(p.id);
    });

    // Copy block HEX
    const colorBlocks = card.querySelectorAll('.palette-card-color-block');
    colorBlocks.forEach((block, index) => {
      block.addEventListener('click', () => {
        const c = p.colors[index];
        copyToClipboard(c, `Copied HEX: ${c}`);
      });
    });

    elements.historyListContainer.appendChild(card);
  });
}

// --- STATE ACTIONS ---

/**
 * Loads colors back from lists into active generator
 */
function loadPaletteIntoGenerator(baseHex, harmonyType) {
  state.baseColor = baseHex;
  state.harmonyType = harmonyType.toLowerCase();
  
  // Sync inputs
  elements.baseColorPicker.value = baseHex;
  elements.colorWheelPreview.style.backgroundColor = baseHex;
  elements.hexTextInput.value = baseHex.replace('#', '');
  
  const [r, g, b] = hexToRgb(baseHex);
  elements.sliderR.value = r;
  elements.sliderG.value = g;
  elements.sliderB.value = b;
  elements.valR.textContent = r;
  elements.valG.textContent = g;
  elements.valB.textContent = b;

  updateSliderTrackColors(r, g, b);

  // Sync harmony pills
  elements.harmonyPills.forEach(pill => {
    if (pill.dataset.harmony === state.harmonyType) {
      pill.classList.add('active');
    } else {
      pill.classList.remove('active');
    }
  });

  // Calculate & Draw
  state.currentPalette = generatePalette(state.baseColor, state.harmonyType);
  renderActivePalette();
  
  // Switch to generate tab
  switchTab('generate');
}

/**
 * Sync UI based on current color selections
 */
function triggerColorUpdate(source) {
  let hexVal = state.baseColor;
  
  if (source === 'picker') {
    hexVal = elements.baseColorPicker.value.toUpperCase();
    state.baseColor = hexVal;
    
    // Sync text input
    elements.hexTextInput.value = hexVal.replace('#', '');
    
    // Sync sliders
    const [r, g, b] = hexToRgb(hexVal);
    elements.sliderR.value = r;
    elements.sliderG.value = g;
    elements.sliderB.value = b;
    elements.valR.textContent = r;
    elements.valG.textContent = g;
    elements.valB.textContent = b;
    
    updateSliderTrackColors(r, g, b);
  } 
  else if (source === 'sliders') {
    const r = parseInt(elements.sliderR.value);
    const g = parseInt(elements.sliderG.value);
    const b = parseInt(elements.sliderB.value);
    
    elements.valR.textContent = r;
    elements.valG.textContent = g;
    elements.valB.textContent = b;
    
    hexVal = rgbToHex(r, g, b);
    state.baseColor = hexVal;
    
    // Sync text and picker
    elements.hexTextInput.value = hexVal.replace('#', '');
    elements.baseColorPicker.value = hexVal;
    
    updateSliderTrackColors(r, g, b);
  }
  else if (source === 'hex') {
    let rawHex = elements.hexTextInput.value.trim();
    if (rawHex.length === 3) {
      rawHex = rawHex.split('').map(c => c + c).join('');
    }
    hexVal = '#' + rawHex.toUpperCase();
    state.baseColor = hexVal;
    
    // Sync picker
    elements.baseColorPicker.value = hexVal;
    
    // Sync sliders
    const [r, g, b] = hexToRgb(hexVal);
    elements.sliderR.value = r;
    elements.sliderG.value = g;
    elements.sliderB.value = b;
    elements.valR.textContent = r;
    elements.valG.textContent = g;
    elements.valB.textContent = b;
    
    updateSliderTrackColors(r, g, b);
  }

  elements.colorWheelPreview.style.backgroundColor = hexVal;
  
  // Calculate palette
  state.currentPalette = generatePalette(state.baseColor, state.harmonyType);
  renderActivePalette();
  
  // Queue history item with debounce
  queueHistorySave();
}

/**
 * Debounces writing updates to history box
 */
function queueHistorySave() {
  if (historyDebounceTimer) {
    clearTimeout(historyDebounceTimer);
  }
  historyDebounceTimer = setTimeout(() => {
    addToHistory(state.baseColor, state.harmonyType, state.currentPalette);
  }, 1000); // 1-second debounce
}

/**
 * Tab switcher controller
 */
function switchTab(tabId) {
  state.activeTab = tabId;
  
  elements.tabBtns.forEach(btn => {
    if (btn.dataset.tab === tabId) {
      btn.classList.add('active');
    } else {
      btn.classList.remove('active');
    }
  });

  elements.tabContents.forEach(content => {
    if (content.id === `tab-${tabId}`) {
      content.classList.add('active');
    } else {
      content.classList.remove('active');
    }
  });

  // Perform tab-specific refreshes
  if (tabId === 'saved') {
    renderSavedPalettes();
  } else if (tabId === 'history') {
    renderHistory();
  }
}

/**
 * Modal state toggle helper
 */
function setSaveModalOpen(isOpen) {
  if (isOpen) {
    elements.paletteNameInput.value = '';
    elements.saveModal.classList.remove('hidden');
    elements.paletteNameInput.focus();
  } else {
    elements.saveModal.classList.add('hidden');
  }
}

/**
 * Theme toggle switcher
 */
function toggleTheme() {
  const isDark = document.body.classList.toggle('dark-theme');
  state.theme = isDark ? 'dark' : 'light';
  localStorage.setItem('themeMode', state.theme);
}

function initTheme() {
  const storedTheme = localStorage.getItem('themeMode');
  if (storedTheme) {
    state.theme = storedTheme;
  } else {
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    state.theme = systemPrefersDark ? 'dark' : 'light';
  }
  
  if (state.theme === 'dark') {
    document.body.classList.add('dark-theme');
  } else {
    document.body.classList.remove('dark-theme');
  }
}

// --- EVENT LISTENERS INITIALIZATION ---

function setupEventListeners() {
  // Theme Toggle
  elements.themeToggle.addEventListener('click', toggleTheme);

  // Tab Buttons
  elements.tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      switchTab(btn.dataset.tab);
    });
  });

  // Color Input Events
  elements.baseColorPicker.addEventListener('input', () => triggerColorUpdate('picker'));
  elements.baseColorPicker.addEventListener('change', () => triggerColorUpdate('picker'));
  
  const handleSliderInput = () => triggerColorUpdate('sliders');
  elements.sliderR.addEventListener('input', handleSliderInput);
  elements.sliderG.addEventListener('input', handleSliderInput);
  elements.sliderB.addEventListener('input', handleSliderInput);

  elements.hexTextInput.addEventListener('input', (e) => {
    let cleanVal = e.target.value.replace(/[^0-9a-fA-F]/g, '');
    e.target.value = cleanVal;
    
    if (cleanVal.length === 3 || cleanVal.length === 6) {
      triggerColorUpdate('hex');
    }
  });

  // Harmony Pills Selector
  elements.harmonyPills.forEach(pill => {
    pill.addEventListener('click', () => {
      elements.harmonyPills.forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      state.harmonyType = pill.dataset.harmony;
      
      // Regenerate palette
      state.currentPalette = generatePalette(state.baseColor, state.harmonyType);
      renderActivePalette();
      queueHistorySave();
    });
  });

  // Save buttons triggers
  elements.savePaletteBtn.addEventListener('click', () => setSaveModalOpen(true));
  elements.modalCancelBtn.addEventListener('click', () => setSaveModalOpen(false));
  
  elements.modalConfirmBtn.addEventListener('click', () => {
    const name = elements.paletteNameInput.value.trim();
    savePalette(name, state.harmonyType, state.currentPalette);
    setSaveModalOpen(false);
    showToast('Palette Saved!');
  });

  elements.paletteNameInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      elements.modalConfirmBtn.click();
    } else if (e.key === 'Escape') {
      setSaveModalOpen(false);
    }
  });

  // Saved Search Input
  elements.savedSearchInput.addEventListener('input', renderSavedPalettes);

  // History Clean
  elements.clearHistoryBtn.addEventListener('click', clearHistory);
}

// --- APP INITIALIZATION ---

document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  setupEventListeners();
  
  // Set up initial state with elements values
  const baseColorHex = '#' + elements.hexTextInput.value.trim().toUpperCase();
  state.baseColor = baseColorHex;
  
  const [r, g, b] = hexToRgb(baseColorHex);
  elements.sliderR.value = r;
  elements.sliderG.value = g;
  elements.sliderB.value = b;
  elements.valR.textContent = r;
  elements.valG.textContent = g;
  elements.valB.textContent = b;
  
  elements.colorWheelPreview.style.backgroundColor = baseColorHex;
  updateSliderTrackColors(r, g, b);
  
  state.currentPalette = generatePalette(state.baseColor, state.harmonyType);
  renderActivePalette();
});
